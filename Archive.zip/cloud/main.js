var createSubmitter = function(submitter){
	var Submitter = new Parse.Object.extend("Submitter");
	var newSubmitter = new Submitter();
	return newSubmitter.save(submitter);
};

var createIdea = function(idea){
	var Idea = new Parse.Object.extend("Idea");
	var newIdea = new Idea();
	return newIdea.save(idea);
}

var incrementSubmissions = function(submitter){
	submitter.increment('submissions');
	return submitter.save();
}

var getTags = function(tags){
	var Tag = new Parse.Object.extend("Tag");
	var query = new Parse.Query(Tag);
	query.containedIn('name', tags);
	return query.find();
}

var incrementTags = function(results, tags){
	for(var i = 0; i < results.length; i++){
		results[i].increment('submissions');
		var index = tags.indexOf(results[i].get('name'));
		tags.splice(index, 1);
	}
	var Tag = new Parse.Object.extend("Tag");
	for(var i = 0; i < tags.length; i++){
		var newTag = new Tag();
		newTag.set('name', tags[i]);
		newTag.set('submissions', 1);
		results.push(newTag);
	}
	return Parse.Object.saveAll(results);
}

Parse.Cloud.define('submitIdea', function(request, response){
	var Submitter = new Parse.Object.extend("Submitter");
	var query = new Parse.Query(Submitter);
	query.equalTo("soeid", request.params.submitter.soeid.toLowerCase());

	var idea = {
		title: request.params.title,
		description: request.params.description,
		d10x: request.params.d10x,
		likes: request.params.likes,
		hideName: request.params.hideName,
		submitter: {},
		visibility: 'Inbox',
		tags: []
	};

	var tags = request.params.tags.toLowerCase().split(', ');

	getTags(tags).then(function(results){
		incrementTags(results, tags).then(function(tagresults){
			idea.tags = tagresults;
		}, function(error){
			idea.tags = [results];
		});
	}, function(error){
		idea.tags = [];
	});

	query.first().then(function(results){
		if(typeof results === 'undefined'){
			var submitter = {
				firstName: request.params.submitter.firstName,
				lastName: request.params.submitter.lastName,
				soeid: request.params.submitter.soeid.toLowerCase(),
				submissions: 1
			}
			createSubmitter(submitter).then(function(results){
				idea.submitter = results;
				createIdea(idea).then(function(results){
					response.success(results);	
				}, function(error){
					response.error(error);
				})
			}, function(error){
				response.error(error);
			});
		}
		else{
			idea.submitter = results;
			incrementSubmissions(results).then(function(results){
				createIdea(idea).then(function(results){
					response.success(results);
				}, function(error){
					response.error(error);
				});
			}, function(error){
				response.error(error);
			});
		}
	}, function(error){
		response.error(error);
	}); 
});